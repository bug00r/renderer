#include "camera.h"

static void setviewport(camera_t * camera, 
						const float l,const float r,const float t,const float b,const float near,const float far){
	camera_t * curcam = camera;
	curcam->l = l;
	curcam->r = r;
	curcam->t = t;
	curcam->b = b;
	curcam->n = near;
	curcam->f = far;
}

void config_camera(camera_t * camera, const vec3_t * from, const vec3_t * to, 
                   const float l,const float r,const float t,const float b,const float near,const float far) {
	camera_t * curcam = camera;
	setviewport(curcam,l,r,t,b,near,far);
	camera_lookAt(curcam, from, to);
	createProjectionOrtho(curcam, l, r, t, b, near, far);
	mat4_copy(&curcam->transformation, &curcam->view);
	mat4_mul(&curcam->transformation, &curcam->projection);

}

void config_camera_perspective(camera_t * camera, const vec3_t * from, const vec3_t * to, 
                   const float l,const float r,const float t,const float b,const float near,const float far) {
	camera_t * curcam = camera;
	setviewport(curcam,l,r,t,b,near,far);
	camera_lookAt_perspective(curcam, from, to);
	createProjectionPerspective(curcam, l, r, t, b, near, far);
	mat4_copy(&curcam->transformation, &curcam->view);
	mat4_mul(&curcam->transformation, &curcam->projection);
}

void 
camera_lookAt(camera_t * camera, const vec3_t * from, const vec3_t * to) {
	const vec3_t * eye = from;
	camera_t * cam = camera;
	
	vec3_sub_dest(&cam->forward, eye, to);
	vec3_normalize(&cam->forward);
	
	vec3_t tmp = { 0.f, 1.f, 0.f};
	vec3_normalize(&tmp);
	
	vec3_cross_dest(&cam->left, &tmp, &cam->forward);
	vec3_normalize(&cam->left);
	
	vec3_cross_dest(&cam->up, &cam->forward, &cam->left);
	vec3_normalize(&cam->up);
	
	cam->projection._11 = cam->left.x;
	cam->projection._21 = cam->left.y;
	cam->projection._31 = cam->left.z;
	cam->projection._41 = 0.f;//-vec3_vec3mul(right, from);
	
	cam->projection._12 = cam->up.x;
	cam->projection._22 = cam->up.y;
	cam->projection._32 = cam->up.z;
	cam->projection._42 = 0.f;//-vec3_vec3mul(up, from);//0.f;
	
	cam->projection._13 = cam->forward.x;
	cam->projection._23 = cam->forward.y;
	cam->projection._33 = cam->forward.z;
	cam->projection._43 = 0.f;//vec3_vec3mul(forward, from);//0.f;
	
	cam->projection._14 = eye->x;
	cam->projection._24 = eye->y;
	cam->projection._34 = eye->z;
	cam->projection._44 = 1.f;
	
	mat4_inverse(&cam->projection);
}

void 
camera_lookAt_perspective(camera_t * camera, const vec3_t * from, const vec3_t * to) {
	const vec3_t * eye = from;
	camera_t * cam = camera;
	vec3_sub_dest(&cam->forward, eye, to);
	vec3_normalize(&cam->forward);
	
	vec3_t tmp = { 0.f, 1.f, 0.f};
	vec3_normalize(&tmp);
	
	vec3_cross_dest(&cam->left, &tmp, &cam->forward);
	vec3_normalize(&cam->left);
	
	vec3_cross_dest(&cam->up, &cam->forward, &cam->left);
	vec3_normalize(&cam->up);

	cam->projection._11 = cam->left.x;
	cam->projection._21 = cam->left.y;
	cam->projection._31 = cam->left.z;
	cam->projection._41 = 0.f;//-vec3_vec3mul(right, from);
	
	cam->projection._12 = cam->up.x;
	cam->projection._22 = cam->up.y;
	cam->projection._32 = cam->up.z;
	cam->projection._42 = 0.f;//-vec3_vec3mul(up, from);//0.f;
	
	cam->projection._13 = -cam->forward.x;
	cam->projection._23 = -cam->forward.y;
	cam->projection._33 = -cam->forward.z;
	cam->projection._43 = 0.f;//vec3_vec3mul(forward, from);//0.f;
	
	cam->projection._14 = eye->x;
	cam->projection._24 = eye->y;
	cam->projection._34 = eye->z;
	cam->projection._44 = 1.f;
	
	mat4_inverse(&cam->projection);
	
}

void 
createProjectionOrtho(camera_t * camera, const float l,const float r,const float t,const float b,const float near,const float far) {
	camera_t * cam = camera;
	cam->view._11 = 2.f/(r-l);
	cam->view._12 = 0.f;
	cam->view._13 = 0.f;
	cam->view._14 = -(r+l)/(r-l);
	
	cam->view._21 = 0.f;
	cam->view._22 = 2.f/(t-b);
	cam->view._23 = 0.f;
	cam->view._24 = -(t+b)/(t-b);
	
	cam->view._31 = 0.f;
	cam->view._32 = 0.f;
	cam->view._33 = -2.f/(far-near);
	cam->view._34 = -(far+near)/(far-near);
	
	cam->view._41 = 0.f;
	cam->view._42 = 0.f;
	cam->view._43 = 0.f;
	cam->view._44 = 1.f;
}

void
createProjectionOrtho2(camera_t * camera,const float r,const float t,const float near,const float far) {
	camera_t * cam = camera;
	cam->view._11 = 1./r;
	cam->view._12 = 0.f;
	cam->view._13 = 0.f;
	cam->view._14 = 0.f;
	
	cam->view._21 = 0.f;
	cam->view._22 = 1./t;
	cam->view._23 = 0.f;
	cam->view._24 = 0.f;
	
	cam->view._31 = 0.f;
	cam->view._32 = 0.f;
	cam->view._33 = -2.f/(far-near);
	cam->view._34 = -(far+near)/(far-near);
	
	cam->view._41 = 0.f;
	cam->view._42 = 0.f;
	cam->view._43 = 1.f;
	cam->view._44 = 1.f;
}
#if 0
	//This is the scratch a pixel version and works fine like the openGL one
#endif
void
createProjectionPerspective_(camera_t * camera, const float l,const float r,const float t,const float b,const float near,const float far) {
	camera_t * cam = camera;
	float scale = 1 / tan(90.f * 0.5f * M_PI / 180.f); 
	cam->view._11 = scale;//(2.f*near)/(r-l);//scale;//
	cam->view._12 = 0.f;
	cam->view._13 = 0.f;//(r+l)/(r-l);
	cam->view._14 = 0.f;
	
	cam->view._21 = 0.f;
	cam->view._22 = scale;//(2.f*near)/(t-b); //scale;//
	cam->view._23 = 0.f;//(t+b)/(t-b);
	cam->view._24 = 0.f;
	
	cam->view._31 = 0.f;
	cam->view._32 = 0.f;
	cam->view._33 = -far/(far-near);
	cam->view._34 = -(far*near)/(far-near);
	
	cam->view._41 = 0.f;
	cam->view._42 = 0.f;
	cam->view._43 = 1.f;
	cam->view._44 = 0.f;
}

#if 0
	//This is the openGL
#endif
void
createProjectionPerspective(camera_t * camera, const float l,const float r,const float t,const float b,const float near,const float far) {
	camera_t * cam = camera;
	float scale = 1 / tan(90.f * 0.5f * M_PI / 180.f); 
	cam->view._11 = scale;//(2.f*near)/(r-l);//scale;//
	cam->view._12 = 0.f;
	cam->view._13 = (r+l)/(r-l);
	cam->view._14 = 0.f;
	
	cam->view._21 = 0.f;
	cam->view._22 = scale;//(2.f*near)/(t-b); //scale;//
	cam->view._23 = (t+b)/(t-b);
	cam->view._24 = 0.f;
	
	cam->view._31 = 0.f;
	cam->view._32 = 0.f;
	cam->view._33 = -(far+near)/(far-near);
	cam->view._34 = -(2.f*far*near)/(far-near);
	
	cam->view._41 = 0.f;
	cam->view._42 = 0.f;
	cam->view._43 = 1.f;
	cam->view._44 = 0.f;
}

void 
print_camera(const camera_t * camera) {
	const camera_t * cam = camera;
	printf("forw.:\t"); vec3_print(&cam->forward);
	printf("left:\t"); vec3_print(&cam->left);
	printf("up:\t"); vec3_print(&cam->up);
	printf("camera:\t"); mat4_print(&cam->view);
	printf("projection:\t"); mat4_print(&cam->projection);
	printf("transformation:\t"); mat4_print(&cam->transformation);
}