void test_pixel_buffer() {
	#ifdef debug
		printf(">> test pixel buffer\n");
	#endif	
	
	#ifdef debug
		printf("<< test pixel buffer\n");
	#endif
}