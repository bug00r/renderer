

is_triangle = istriangle(shape);
is_line = !is_triangle && isline(shape);
is_point = !is_line && ispoint(shape);

isVisible = false;
over_z = FLT_MAX;
completeout = true;

for(unsigned int ipdnc = shape->cntVertex; ipdnc-- ;) {
	
	ndc = &pNDC[ipdnc];
	raster = &pRaster[ipdnc];
	fweight = &weight[ipdnc];
	vertex = vertices[ipdnc];
	
	vcolors[ipdnc] = &vertex->color;
	
	*fweight = 1.f/transform_point_dest(ndc, transformation, &vertex->vec);
	
	if (*fweight < 0.f) return;
	
	raster->x = (ndc->x + 1.f) * imgW_h;
	raster->y = (1.f-ndc->y) * imgH_h;
	raster->z = -ndc->z;
	
	//this is only a test. here we should implement complete fine frustum culling
	if (completeout) {
		completeout &= ( (ndc->x < cam->l) ||(ndc->x > cam->r));
		completeout &= ( (ndc->y < cam->b) ||(ndc->y > cam->t));
	}

	#ifdef debug
		add_debug_head(renderer, " ****** shape[%u]******* ", ipdnc);
		add_debug_head(renderer, "vtx[%u](x/y/z):\t %f %f %f", ipdnc, vertex->vec.x,
																		vertex->vec.y,
																		vertex->vec.z);
		add_debug_head(renderer, "NDC[%u](x/y/z):\t %f %f %f", ipdnc, ndc->x, ndc->y, ndc->z);
		add_debug_head(renderer, "RS [%u](x/y/z):\t %f %f %f", ipdnc, raster->x, raster->y, raster->z);
	#endif
}
//this is only a test. here we should implement complete fine frustum culling
if (completeout) return;

if (is_triangle) {
	bc.area = place_of_vec3(&pRaster[0], &pRaster[1], &pRaster[2]); 
	#ifdef debug
		add_debug_head(renderer, "bc.area:\t %f:", bc.area);
	#endif
}
