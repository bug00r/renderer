if(is_triangle) {
	maxx = fmin((float)imgW, fmax(pRaster[0].x, fmax(pRaster[1].x, pRaster[2].x)));
	maxy = fmin((float)imgH, fmax(pRaster[0].y, fmax(pRaster[1].y, pRaster[2].y)));
	minx = fmax(0, fmin(pRaster[0].x, fmin(pRaster[1].x, pRaster[2].x)));
	miny = fmax(0, fmin(pRaster[0].y, fmin(pRaster[1].y, pRaster[2].y)));
	
} else if (is_line) {
	maxx = fmin((float)imgW, fmax(pRaster[0].x, pRaster[1].x));
	maxy = fmin((float)imgH, fmax(pRaster[0].y, pRaster[1].y));
	minx = fmax(0, fmin(pRaster[0].x, pRaster[1].x));
	miny = fmax(0, fmin(pRaster[0].y, pRaster[1].y));
	
	if ( minx == maxx ) {
		minx -= 2.f; maxx+=2.f;
	}
	
	if ( miny == maxy ) {
		miny -= 2.f; maxy+=2.f;
	}
} else if (is_point) {
	maxx = 1.f;
	maxy = 1.f;
	minx = 0.f;
	miny = 0.f;
}

curH = miny;
curW = minx;

#ifdef debug
	add_debug_head(renderer, "bbox(min|max):\t %f %f|%f %f", minx, miny, maxx, maxy);
#endif