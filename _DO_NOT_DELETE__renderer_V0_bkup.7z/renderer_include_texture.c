	
vec2_t *tex1 = &vertices[0]->texCoord, 
	   *tex2 = &vertices[1]->texCoord, 
	   *tex3 = &vertices[2]->texCoord;

#ifdef debug 
	add_debug_output(renderer, bi, "tex raw:", 1);
	add_debug_output(renderer, bi, "tex1:\t\t %f %f", tex1->x, tex1->y);
	add_debug_output(renderer, bi, "tex2:\t\t %f %f", tex2->x, tex2->y);
	add_debug_output(renderer, bi, "tex3:\t\t %f %f", tex3->x, tex3->y);
#endif

float texx =( z0*tex1->x + z1*tex2->x + z2*tex3->x ) * z3;
float texy =( z0*tex1->y + z1*tex2->y + z2*tex3->y ) * z3;

#ifdef debug 
	add_debug_output(renderer, bi, "tex z corrected:", 1);
	add_debug_output(renderer, bi, "texx:\t\t %f (%f)", texx, z3);
	add_debug_output(renderer, bi, "texy:\t\t %f (%f)", texy, z3);
#endif

texx *= 512.f;
texy *= 512.f;

#ifdef debug
	add_debug_output(renderer, bi, "tex after interpolation:", 1);
	add_debug_output(renderer, bi, "texx:\t\t %f", texx);
	add_debug_output(renderer, bi, "texy:\t\t %f", texy);
#endif

int texIndex = floor(texy) * imgW + floor(texx);
crgb_crgb_copy(&curCol1, &renderer->texture[texIndex]);
