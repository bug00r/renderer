#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "renderer_v1.h"
#include "scene_builder.h"
#include "texture.h"

renderer_t * create_renderer(int width, int height,
									vec3_t *from, vec3_t* to, 
									float zoom, 
									float left, float right, 
									float top, float bottom, 
									float near, float far,
									cRGB_t *bgcolor) {
    renderer_t *renderer = renderer_new(width, height, bgcolor);
	config_camera(&renderer->camera, from, to, zoom * left, zoom * right, zoom * top, zoom * bottom, near, far);
	return renderer;
}

renderer_t * create_test_base_renderer() {
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 1.f, 1.0f, 2.0f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer(
									512 /*width*/, 512/*height*/,
									&from, &to, 
									0.5f /* zoom */,
									-2.f /* left */, 2.f /*right*/, 
									2.f /* top */, -2.f /*bottom*/, 
									1.f /* near */, 100.f /*far*/,
									&bgcolor);
	return renderer;
}

renderer_t * create_renderer_perspective(int width, int height,
									vec3_t *from, vec3_t* to, 
									float zoom, 
									float left, float right, 
									float top, float bottom, 
									float near, float far,
									cRGB_t *bgcolor) {
    renderer_t *renderer = renderer_new(width, height, bgcolor);
	renderer->projection = RP_PERSPECTIVE;
	config_camera_perspective(&renderer->camera, from, to, zoom * left, zoom * right, zoom * top, zoom * bottom, near, far);
	return renderer;
}

renderer_t * create_test_base_renderer_perspective() {
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 1.f, 1.0f, 1.f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer_perspective(
									512 /*width*/, 512/*height*/,
									&from, &to, 
									1.0f /* zoom */,
									-2.f /* left */, 2.f /*right*/, 
									2.f /* top */, -2.f /*bottom*/, 
									1.f /* near */, 5.f /*far*/,
									&bgcolor);
	return renderer;
}

void test_renderer_creation() {
	cRGB_t bgcolor = {0.f, 0.f, 0.f};
	int w = 256;
	int h = 256;
	renderer_t * renderer = renderer_new(w, h, &bgcolor);
	
	assert(renderer->imgWidth == w);
	assert(renderer->imgHeight == h);
	
	int buffsize = w*h;
	float zbuffervalue = 5.f;
	
	renderer->frameBuffer[buffsize-1].r = 0.5f;
	renderer->frameBuffer[buffsize-1].g = 0.25f;
	renderer->frameBuffer[buffsize-1].b = 0.125f;
	renderer->zBuffer[buffsize-2] = zbuffervalue;
	
	assert(renderer->frameBuffer[buffsize-1].r == 0.5f);
	assert(renderer->frameBuffer[buffsize-1].g == 0.25f);
	assert(renderer->frameBuffer[buffsize-1].b == 0.125f);
	
	assert(renderer->zBuffer[buffsize-1] == FLT_MAX);
	assert(renderer->zBuffer[buffsize-2] == zbuffervalue);
	
	assert(renderer->imgWidth == w);
	assert(renderer->imgHeight == h);
	renderer_free(renderer);
}

void addBackgroundToRenderer(renderer_t * renderer) {
	texture2_t * texture_fractals = texture2_new(renderer->imgWidth,renderer->imgHeight);
	
	mandelbrot_t *mb = mandelbrot_new(renderer->imgWidth, renderer->imgHeight);
	mb->minreal = -2.f;//-1.3f;
	mb->maxreal = 0.5f;//-1.f;
	mb->minimag = -1.f;//-.3f;
	mb->maximag = 1.f;//0.f;
	mb->cntiterations = 20;
	create_mandelbrot(mb);
	
	mandelbrot_to_texture(mb, texture_fractals, mandelbrot_color_line_int_rgb);
	
	int bufsize = renderer->imgWidth*renderer->imgHeight*sizeof(cRGB_t);
	memcpy(renderer->frameBuffer, texture_fractals->buffer->entries, bufsize);
    
	mandelbrot_free(mb);
	texture2_free(texture_fractals);
}

void test_render_points(renderer_t * renderer, bool isperspective) {
	vec3_t p = { 0.0f, 0.0f, 0.f };
	mesh_t * points = create_point3(&p);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, points);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_points.ppm" : 
													"build/points.ppm"));
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, points);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_points_4xMSAA.ppm" : 
													"build/points_4xMSAA.ppm"));
	free_mesh(points);
}

void test_render_lines(renderer_t * renderer, bool isperspective) {
	
	vec3_t p = { -1.f, -1.0f, 0.f };
	vec3_t p2 = { -.8f, 1.0f, 0.f };
	mesh_t * line = create_line3(&p, &p2);
	
	cRGB_t red = {1.f, 0.f, 0.f};
	set_shape_color(line->shapes[0], &red);
	
	renderer->samplestep = 1.f;
	float step = 0.f;
	for ( int i = 0; i < 20; ++i, step+=0.05f) {
		line->shapes[0]->vertices[1]->vec.x += step;
		line->shapes[0]->vertices[1]->vec.y -= step;
		line->shapes[0]->vertices[1]->vec.z += step;
		render_mesh(renderer, line);
	}
	
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_line.ppm" : 
													"build/line.ppm"));
													
	free_mesh(line);
	renderer_clear_frame(renderer);
	
	p = (vec3_t ){ -1.f, -1.0f, 0.f };
	p2 = (vec3_t ){ -.8f, 1.0f, 0.f };
	line = create_line3(&p, &p2);
	
	renderer->samplestep = 4.f;
	
	step = 0.f;
	for ( int i = 0; i < 20; ++i, step+=0.05f) {
		line->shapes[0]->vertices[1]->vec.x += step;
		line->shapes[0]->vertices[1]->vec.y -= step;
		line->shapes[0]->vertices[1]->vec.z += step;
		render_mesh(renderer, line);
	}
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_line_4xMSAA.ppm" : 
													"build/line_4xMSAA.ppm"));
	
	free_mesh(line);
}

void test_render_triangle(renderer_t * renderer, bool isperspective) {
	vec3_t p1 = { -0.75f, -0.75f, 0.75f };
	vec3_t p2 = { 0.75f, -0.55f, 0.25f };
	vec3_t p3 = { 0.05f, 0.75f, -0.75f };
	
	//1. add triangle
	mesh_t * triangle = create_triangle3(&p1, &p2, &p3);
	
	renderer->samplestep = 1.f;
	
	render_mesh(renderer, triangle);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_triangle.ppm" : 
													"build/triangle.ppm"));
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, triangle);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_triangle_4xMSAA.ppm" : 
													"build/triangle_4xMSAA.ppm"));
	
	free_mesh(triangle);
}

void test_render_quad(renderer_t * renderer, bool isperspective) {

	vec3_t p1 = { -0.75f, -0.75f, 0.75f };
	vec3_t p2 = { 0.75f, -0.75f, 0.75f };
	vec3_t p3 = { -0.75f, 0.75f, 0.75f };
	vec3_t p4 = { 0.75f, 0.75f, 0.75f };
	mesh_t * quad = create_quad3( &p1, &p2, &p3, &p4);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, quad);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_quad.ppm" : 
													"build/quad.ppm"));
													
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, quad);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_quad_4xMSAA.ppm" : 
													"build/quad_4xMSAA.ppm"));
	
	renderer_clear_frame(renderer);
	
	mat3_t * rotz_mat = create_rot_z_mat(40.f);
	mat_mul_mesh(quad, rotz_mat);
	free(rotz_mat);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, quad);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_quad_rot_z_40.ppm" : 
													"build/quad_rot_z_40.ppm"));
													
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, quad);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_quad_4xMSAA_rot_z_40.ppm" : 
													"build/quad_4xMSAA_rot_z_40.ppm"));
	renderer_clear_frame(renderer);
	
	rotz_mat = create_rot_z_mat(65.f);
	mat_mul_mesh(quad, rotz_mat);
	free(rotz_mat);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, quad);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_quad_rot_z_65.ppm" : 
													"build/quad_rot_z_65.ppm"));
	
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, quad);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_quad_4xMSAA_rot_z_65.ppm" : 
													"build/quad_4xMSAA_rot_z_65.ppm"));
	
	free_mesh(quad);
	
}


void test_render_cube(renderer_t * renderer, bool isperspective) {

	vec3_t center = { 0.f, 0.f, 0.f };
	mesh_t * cube = create_cube3_center(&center, 1.f);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, cube);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cube.ppm" : 
													"build/cube.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_perspective_cube.ppm" : 
															 "build/z_buffer__perspective_cube.ppm"));
	
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, cube);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cube_4xMSAA.ppm" : 
													"build/cube_4xMSAA.ppm"));
	
	renderer_clear_frame(renderer);
	
	
	mat3_t * rotz_mat = create_rot_z_mat(45.f);
	mat3_t * rotx_mat = create_rot_x_mat(45.f);
	mat3_mul(rotz_mat, rotx_mat);
	
	mat_mul_mesh(cube, rotz_mat);
	free(rotz_mat);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, cube);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cube_rot_z_45.ppm" : 
													"build/cube_rot_z_45.ppm"));
	
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, cube);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cube_4xMSAA_rot_z_45.ppm" : 
													"build/cube_4xMSAA_rot_z_45.ppm"));
	
	renderer_clear_frame(renderer);
	
	
	rotz_mat = create_rot_z_mat(65.f);
	rotx_mat = create_rot_x_mat(45.f);
	mat3_mul(rotz_mat, rotx_mat);
	mat_mul_mesh(cube, rotz_mat);
	free(rotz_mat);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, cube);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cube_rot_z_65.ppm" : 
													"build/cube_rot_z_65.ppm"));
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_cube_rot_z_65.ppm" : 
															 "build/z_buffer_cube_rot_z_65.ppm"));
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, cube);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cube_4xMSAA_rot_z_65.ppm" : 
													"build/cube_4xMSAA_rot_z_65.ppm"));
													
	free(rotx_mat);
	free_mesh(cube);
}

void test_render_sphere(renderer_t * renderer, bool isperspective) {
	mesh_t * sphere = createsphere(0.5f, 50, 50);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, sphere);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_sphere.ppm" : 
													"build/sphere.ppm"));
	
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, sphere);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_sphere_4xMSAA.ppm" : 
													"build/sphere_4xMSAA.ppm"));
	
	renderer_clear_frame(renderer);
	
	
	mat3_t * rotz_mat = create_rot_z_mat(45.f);
	mat3_t * rotx_mat = create_rot_x_mat(225.f);
	mat3_mul(rotz_mat, rotx_mat);
	
	mat_mul_mesh(sphere, rotz_mat);
	free(rotz_mat);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, sphere);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_sphere_rot_z_45.ppm" : 
													"build/sphere_rot_z_45.ppm"));
	
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, sphere);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_sphere_4xMSAA_rot_z_45.ppm" : 
													"build/sphere_4xMSAA_rot_z_45.ppm"));
	
	renderer_clear_frame(renderer);
	
	rotz_mat = create_rot_z_mat(65.f);
	rotx_mat = create_rot_x_mat(45.f);
	mat3_mul(rotz_mat, rotx_mat);
	mat_mul_mesh(sphere, rotz_mat);
	free(rotz_mat);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, sphere);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_sphere_rot_z_65.ppm" : 
													"build/sphere_rot_z_65.ppm"));
													
	renderer_clear_frame(renderer);
	
	renderer->samplestep = 4.f;
	render_mesh(renderer, sphere);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_sphere_4xMSAA_rot_z_65.ppm" : 
													"build/sphere_4xMSAA_rot_z_65.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_sphere_4xMSAA_rot_z_65.ppm" : 
															 "build/z_buffer_sphere_4xMSAA_rot_z_65.ppm"));
	
	free(rotx_mat);
	free_mesh(sphere);
}

void test_render_test_scene(renderer_t * renderer, bool isperspective) {
	//scene_t * scene = scene_create_test();
	scene_t * scene = scene_create_test_all();
	
	renderer->samplestep = 1.f;
	render_scene(renderer, scene);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_testscene.ppm" : 
													"build/testscene.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_testscene.ppm" : 
															 "build/z_buffer_testscene.ppm"));
	
	renderer_clear_frame(renderer);
	addBackgroundToRenderer(renderer);
	
	renderer->samplestep = 4.f;
	render_scene(renderer, scene);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_testscene_4xMSAA.ppm" : 
													"build/testscene_4xMSAA.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_testscene_4xMSAA.ppm" : 
															 "build/z_buffer_testscene_4xMSAA.ppm"));
	
	mat3_t * rotz_mat = create_rot_z_mat(0.f);
	mat3_t * rotx_mat = create_rot_x_mat(45.f);
	mat3_mul(rotz_mat, rotx_mat);
	
	mat_mul_scene(scene, rotz_mat);
	free(rotz_mat);
	free(rotx_mat);
	
	renderer_clear_frame(renderer);
	addBackgroundToRenderer(renderer);
	renderer->samplestep = 1.f;
	render_scene(renderer, scene);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_testscene_rot_z_45.ppm" : 
													"build/testscene_rot_z_45.ppm"));
													
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_testscene_rot_z_45.ppm" : 
															 "build/z_buffer_testscene_rot_z_45.ppm"));
	
	renderer_clear_frame(renderer);
	addBackgroundToRenderer(renderer);
	renderer->samplestep = 4.f;
	render_scene(renderer, scene);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_testscene_4xMSAA_rot_z_45.ppm" : 
													"build/testscene_4xMSAA_rot_z_45.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_testscene_4xMSAA_rot_z_45.ppm" : 
															 "build/z_buffer_testscene_4xMSAA_rot_z_45.ppm"));
	
	renderer_clear_frame(renderer);
	addBackgroundToRenderer(renderer);
	rotx_mat = create_rot_x_mat(-45.f);
	mat_mul_scene(scene, rotx_mat);
	free(rotx_mat);
	
	rotz_mat = create_rot_y_mat(45.f);
	rotx_mat = create_rot_x_mat(45.f);
	mat3_mul(rotz_mat, rotx_mat);
	mat_mul_scene(scene, rotz_mat);
	
	free(rotz_mat);
	free(rotx_mat);
	
	renderer->samplestep = 1.f;
	render_scene(renderer, scene);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_testscene_rot_z_65.ppm" : 
													"build/testscene_rot_z_65.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_testscene_rot_z_65.ppm" : 
															 "build/z_buffer_testscene_rot_z_65.ppm"));
	
	renderer_clear_frame(renderer);
	addBackgroundToRenderer(renderer);
	renderer->samplestep = 4.f;
	render_scene(renderer, scene);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_testscene_4xMSAA_rot_z_65.ppm" : 
													"build/testscene_4xMSAA_rot_z_65.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_testscene_4xMSAA_rot_z_65.ppm" : 
															 "build/z_buffer_testscene_4xMSAA_rot_z_65.ppm"));
	
	free_scene(scene);
}

void test_render_texture_cube() {
	bool isperspective = false;
	unsigned int w_ = 512;
	unsigned int h_ = 512;
	texture2_t * texture_fractals = texture2_new(w_,h_);
	
	mandelbrot_t *mb = mandelbrot_new(w_, h_);
	mb->minreal = -2.f;//-1.3f;
	mb->maxreal = 0.5f;//-1.f;
	mb->minimag = -1.f;//-.3f;
	mb->maximag = 1.f;//0.f;
	mb->cntiterations = 20;
	create_mandelbrot(mb);
	
	mandelbrot_to_texture(mb, texture_fractals, mandelbrot_color_line_int_rgb);
	
	cRGB_t bgcolor = {1.f, 0.5f, 0.f};
	renderer_t * renderer_active_tex = renderer_new(w_, h_, &bgcolor);
	int bufsize = w_*h_*sizeof(cRGB_t);
	renderer_active_tex->texture = malloc(bufsize);
	memcpy(renderer_active_tex->texture, texture_fractals->buffer->entries, bufsize);
    
	mandelbrot_free(mb);
	texture2_free(texture_fractals);
	
	vec3_t _from = { 0.5f, 0.34f, 1.f };
	vec3_t _to = { 0.0f, 0.0f, 0.0f };
	float zoom = .25f;
	float bottom = 1.f;
	float left = 1.f;
	config_camera(&renderer_active_tex->camera, &_from, &_to, zoom * -left, zoom * left, zoom * bottom, zoom * -bottom, 1.f, 5.f);
	
	scene_t * texscene = scene_create_texture_test();
	
	renderer_active_tex->samplestep = 1.f;
	render_scene(renderer_active_tex, texscene);
	renderer_output_ppm(renderer_active_tex, ( isperspective ? "build/__perspective_RENDER_tex.ppm" : 
															   "build/RENDER_tex.ppm"));
	
	renderer_active_tex->samplestep = 4.f;
	render_scene(renderer_active_tex, texscene);
	renderer_output_ppm(renderer_active_tex, ( isperspective ? "build/__perspective_RENDER_tex_4xMSAA.ppm" : 
															   "build/RENDER_tex_4xMSAA.ppm"));

	free_scene(texscene);	
	renderer_free(renderer_active_tex);
}

void test_render_cylinder(renderer_t * renderer, bool isperspective) {
	//createcylinder(float radius, float height, unsigned int longs, unsigned lats, bool showtop, bool showbottom)
	mesh_t * cylinder = createcylinder(0.5f, 1.5f, 30, 30, true, true);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, cylinder);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cylinder.ppm" : 
													"build/cylinder.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_cylinder.ppm" : 
															 "build/z_buffer_cylinder.ppm"));
	
	
	
	mat3_t * rotx_mat = create_rot_x_mat(-45.f);
	mat3_t * roty_mat = create_rot_y_mat(0.f);
	mat3_mul(rotx_mat, roty_mat);
	
	mat_mul_mesh(cylinder, rotx_mat);
	free(rotx_mat);
	free(roty_mat);
	
	
	renderer_clear_frame(renderer);
	renderer->samplestep = 1.f;
	render_mesh(renderer, cylinder);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cylinder_rotx_45.ppm" : 
													"build/cylinder_rotx_45.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_cylinder_rotx_45.ppm" : 
															 "build/z_buffer_cylinder_rotx_45.ppm"));
	
	free_mesh(cylinder);
}

void test_render_cone(renderer_t * renderer, bool isperspective) {
	//	mesh_t * createcone(float radius, float height, unsigned int lats, bool showbottom);
	mesh_t * cone = createcone(0.5f, 1.5f, 10, true);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, cone);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cone.ppm" : 
													"build/cone.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_cone.ppm" : 
															 "build/z_buffer_cone.ppm"));
	
	
	
	mat3_t * rotx_mat = create_rot_x_mat(-45.f);
	mat_mul_mesh(cone, rotx_mat);
	free(rotx_mat);
	
	
	renderer_clear_frame(renderer);
	renderer->samplestep = 1.f;
	render_mesh(renderer, cone);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_cone_rotx_45.ppm" : 
													"build/cone_rotx_45.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_cone_rotx_45.ppm" : 
															 "build/z_buffer_cone_rotx_45.ppm"));
	
	free_mesh(cone);
}



void test_render_square_block(renderer_t * renderer, bool isperspective) {
	#ifdef debug
		printf(">> test render square block\n");
	#endif

	vec3_t center = { 0.f, 0.f, 0.f };
	mesh_t * square_block = create_square_block(&center, 1.f, 2.f, 3.f, 1, 2, 3);
	
	renderer->samplestep = 1.f;
	render_mesh(renderer, square_block);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_square_block.ppm" : 
													"build/square_block.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_square_block.ppm" : 
															 "build/z_buffer_square_block.ppm"));
	#ifdef debug
		printf("without rotation:\n");
		printf("min_z:\t%f\n", renderer->min_z);
		printf("max_z:\t%f\n", renderer->max_z);
	#endif
	
	mat3_t * rotz_mat = create_rot_z_mat(0.f);
	mat3_t * rotx_mat = create_rot_x_mat(20.f);
	mat3_t * roty_mat = create_rot_y_mat(20.f);
	mat3_mul(rotz_mat, rotx_mat);
	mat3_mul(rotz_mat, roty_mat);
	mat_mul_mesh(square_block, rotz_mat);
	
	free(rotz_mat);
	free(rotx_mat);
	free(roty_mat);	
	
	renderer_clear_frame(renderer);
	renderer->samplestep = 1.f;
	render_mesh(renderer, square_block);
	renderer_output_ppm(renderer, ( isperspective ? "build/__perspective_square_block_rotx_45.ppm" : 
													"build/square_block_rotx_45.ppm"));
	
	renderer_output_z_buffer_ppm(renderer, ( isperspective ? "build/___z_buffer_perspective_square_block_rotx_45.ppm" : 
															 "build/z_buffer_square_block_rotx_45.ppm"));
	
	#ifdef debug
		printf("with rotation:\n");
		printf("min_z:\t%f\n", renderer->min_z);
		printf("max_z:\t%f\n", renderer->max_z);
	#endif
	
	free_mesh(square_block);
	
	#ifdef debug
		printf("<< test render square block\n");
	#endif
}

void test_projection_shape(renderer_t *renderer, shape_t * shape, vec2_t * trigger_pixel, unsigned int cnttrigger )
{
	#ifdef debug
		printf("################################################\n");
		printf("################# SHAPE ########################\n");
		printf("################################################\n");
	#endif
	renderer_transformation_t * rt = render_transformation_new();
	process_world_to_raster(renderer, shape, rt);
	
	#ifdef debug
	for(unsigned int curVertex = 0; curVertex < shape->cntVertex ; ++curVertex) {
		vertex_t * vertex = shape->vertices[curVertex];
	
		printf("[%i]world:\t", curVertex); vec3_print(&vertex->vec);
		printf("[%i]ndc:\t\t", curVertex); vec3_print(rt->pNDC[curVertex]);
		printf("[%i]raster:\t", curVertex); vec3_print(rt->pRaster[curVertex]);		
		printf("[%i]color:\t", curVertex); crgb_print(&vertex->color);
	}
	#endif
	process_bounding_box(rt);
	
	#ifdef debug
		printf("samples:\t%f\n", rt->renderer->samplestep);
		printf("b-box:\t\tminx: %f miny: %f maxx: %f maxy: %f\n", rt->minx, rt->miny, rt->maxx, rt->maxy);
	#endif

	if ( trigger_pixel != NULL ) {
		#ifdef debug
		printf("]]]- ----  Fire Pixel against shape:\n");
		#endif
		for ( unsigned int curpx = 0; curpx < cnttrigger; ++curpx) {
			#ifdef debug
				printf("####### Pixel ##########\n");
			#endif
			vec2_t triggerpx = trigger_pixel[curpx];
			rt->curW = triggerpx.x;
			rt->curH = triggerpx.y;
			process_single_pixel(rt);
			#ifdef debug
				printf("curPx:\t\t"); vec3_print(&rt->pixelSample);
				printf("visible:\t%i\n", rt->isVisible);
				printf("barycentric:\n");
				print_barycentric(&rt->bc);
				printf("z, over_z:\t%f, %f\n", rt->z, rt->over_z);
				cRGB_t * color = &rt->renderer->frameBuffer[rt->curH * rt->renderer->imgWidth + rt->curW];
				printf("color:\t %f %f %f\n", color->r, color->g, color->b);
			#endif

		}
	}

	render_transformation_free(rt);
}

void test_render_projection() {
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 0.f, 0.f, 2.0f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer(
									32 /*width*/, 32/*height*/,
									&from, &to, 
									1.0f /* zoom */,
									-1.f /* left */, 1.f /*right*/, 
									1.f /* top */, -1.f /*bottom*/, 
									1.f /* near */, 100.f /*far*/,
									&bgcolor);
	
	#ifdef debug
		printf("from:\t"); vec3_print(&from);
		printf("to:\t"); vec3_print(&to);
		print_camera(&renderer->camera);
	#endif	
	
	vec3_t p1 = { 0.f, 0.f, 0.f };
	shape_t * shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif

	p1 = (vec3_t){ -0.5f, -0.5f, 0.5f };
	shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif
	
	p1 = (vec3_t){ -0.5f, -0.5f, -0.5f };
	shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif
	
	p1 = (vec3_t){ -0.5f, -0.5f, -20.f };
	shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif
	
	p1 = (vec3_t){ -0.5f, -0.5f, 0.5f };
	vec3_t p2 = { 0.5f, 0.5f, -5.f };
	shape = create_shape_line3(&p1, &p2);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	p1 = (vec3_t){ -0.5f, -0.5f, 0.5f };
	p2 = (vec3_t){ 0.5f, -0.5f, 0.5f };
	vec3_t p3 = {-0.5f, 0.5f, 0.5f};
	shape = create_shape_triangle3(&p1, &p2, &p3);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);

	vec3_t p4 = {0.5f, 0.5f, 0.5f};
	shape = create_shape_triangle3(&p3, &p2, &p4);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	p1.z = -.5f;
	p2.z = -.5f;
	p3.z = -.5f;
	p4.z = -.5f;
	
	shape = create_shape_triangle3(&p2, &p1, &p4);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	shape = create_shape_triangle3(&p4, &p1, &p3);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	renderer_free(renderer);
}

void
test_render_projection_square_block() {
	#ifdef debug
		printf(">> Projection square block\n");
	#endif
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 0.f, 0.f, 2.0f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer(
									512 /*width*/, 512/*height*/,
									&from, &to, 
									1.0f /* zoom */,
									-2.f /* left */, 2.f /*right*/, 
									2.f /* top */, -2.f /*bottom*/, 
									1.f /* near */, 100.f /*far*/,
									&bgcolor);
	
	vec3_t center = { 0.f, 0.f, 0.f };
	mesh_t * square_block = create_square_block(&center, 1.f, 1.f, 1.f, 1, 1, 1);			

	mat3_t * rotz_mat = create_rot_z_mat(0.f);
	mat3_t * rotx_mat = create_rot_x_mat(20.f);
	mat3_t * roty_mat = create_rot_y_mat(20.f);
	mat3_mul(rotz_mat, rotx_mat);
	mat3_mul(rotz_mat, roty_mat);
	mat_mul_mesh(square_block, rotz_mat);
	
	free(rotz_mat);
	free(rotx_mat);
	free(roty_mat);	
	
	
	vec2_t triggerpixel[2] = {
		(vec2_t) {138.f, 81.f },
		(vec2_t) {274.f, 200.f }
	};
	
	for(unsigned int curShape = 0; curShape < square_block->cntShapes; ++curShape) {
		shape_t * shape = square_block->shapes[curShape];
		test_projection_shape(renderer, shape, triggerpixel, 2);
	}
	
	#ifdef debug
		printf("min_z:\t%f\n", renderer->min_z);
		printf("max_z:\t%f\n", renderer->max_z);
	#endif
	
	free_mesh(square_block);
	#ifdef debug
		printf("<< Projection square block\n");
	#endif
}

void
test_render_projection_triangle() {
	#ifdef debug
		printf(">> Projection Triangle\n");
	#endif
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 0.f, 0.f, 2.0f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer(
									512 /*width*/, 512/*height*/,
									&from, &to, 
									0.5f /* zoom */,
									-2.f /* left */, 2.f /*right*/, 
									2.f /* top */, -2.f /*bottom*/, 
									1.f /* near */, 100.f /*far*/,
									&bgcolor);
	
	vec3_t p1 = { -0.75f, -0.75f, 0.75f };
	vec3_t p2 = { 0.75f, -0.55f, 0.25f };
	vec3_t p3 = { 0.05f, 0.75f, -0.75f };
	
	shape_t * triangle = create_shape_triangle3(&p1, &p2, &p3);			

	
	vec2_t triggerpixel[2] = {
		(vec2_t) {66.f, 445.f },
		(vec2_t) {268.f, 70.f }
	};
	
	test_projection_shape(renderer, triangle, triggerpixel, 2);

	#ifdef debug
		printf("min_z:\t%f\n", renderer->min_z);
		printf("max_z:\t%f\n", renderer->max_z);
	#endif
	
	free_shape(triangle);
	#ifdef debug
		printf("<< Projection Triangle\n");
	#endif
}

void
test_render_texturing() {
	unsigned int w_ = 512;
	unsigned int h_ = 512;
	texture2_t * texture_fractals = texture2_new(w_,h_);
	
	mandelbrot_t *mb = mandelbrot_new(w_, h_);
	mb->minreal = -2.f;//-1.3f;
	mb->maxreal = 0.5f;//-1.f;
	mb->minimag = -1.f;//-.3f;
	mb->maximag = 1.f;//0.f;
	mb->cntiterations = 20;
	create_mandelbrot(mb);
	
	mandelbrot_to_texture(mb, texture_fractals, mandelbrot_color_line_int_rgb);
	
	cRGB_t bgcolor = {1.f, 0.5f, 0.f};
	renderer_t * renderer_active_tex = renderer_new(w_, h_, &bgcolor);
	int bufsize = w_*h_*sizeof(cRGB_t);
	renderer_active_tex->texture = malloc(bufsize);
	memcpy(renderer_active_tex->texture, texture_fractals->buffer->entries, bufsize);
    
	mandelbrot_free(mb);
	texture2_free(texture_fractals);
	
	vec3_t _from = { 0.5f, 0.34f, 1.f };
	vec3_t _to = { 0.0f, 0.0f, 0.0f };
	float zoom = .25f;
	float bottom = 1.f;
	float left = 1.f;
	config_camera(&renderer_active_tex->camera, &_from, &_to, zoom * -left, zoom * left, zoom * bottom, zoom * -bottom, 1.f, 5.f);
	
	scene_t * texscene = scene_create_texture_test();		
	
	vec2_t triggerpixel[4] = {
		(vec2_t) {84.f, 151.f },
		(vec2_t) {312.f, 168.f },
		(vec2_t) {84.f, 394.f },
		(vec2_t) {312.f, 427.f }
	};
	
	mesh_t * texcube = texscene->meshes[0];
	
	for(unsigned int curShape = 0; curShape < texcube->cntShapes; ++curShape) {
		shape_t * shape = texcube->shapes[curShape];
		test_projection_shape(renderer_active_tex, shape, triggerpixel, 4);
	}

	free_scene(texscene);	
	renderer_free(renderer_active_tex);
}

int 
main() {
	#ifdef debug
		printf("Start test renderer\n");;
	#endif	
	
	//test_renderer_creation();
	//
	//test_render_projection();
	
	#if 0
		//this ist because z buffer is inverted ?!
	#endif
	//test_render_projection_square_block();
	//
	//test_render_projection_triangle();
	
	//test_render_texturing();
	
	renderer_t *renderer = create_test_base_renderer();
	
	test_render_cylinder(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_cone(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
    
	test_render_square_block(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_points(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	printf("TEST RENDER LINES IS BROKEN!!!\n");
	test_render_lines(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_triangle(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_quad(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_cube(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_sphere(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	addBackgroundToRenderer(renderer);
	test_render_test_scene(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_texture_cube();
	
	renderer_free(renderer);
    
	//perspective rendering
	renderer = create_test_base_renderer_perspective();
	
	test_render_points(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	printf("TEST RENDER LINES IS BROKEN!!!\n");
	test_render_lines(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_triangle(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_quad(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_cube(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	test_render_sphere(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	addBackgroundToRenderer(renderer);
	test_render_test_scene(renderer, renderer->projection == RP_PERSPECTIVE);
	renderer_clear_frame(renderer);
	
	
	renderer_free(renderer);
	
	#ifdef debug
		printf("End test renderer\n");
	#endif	
	
	return 0;
}