#if 0
/**
	This is a simple rendereing engine. 
*/
#endif

#ifndef RENDERER_H
#define RENDERER_H

#include <float.h>
#include <math.h>
#include <stdbool.h>

#include "vec.h"
#include "mat.h"
#include "utils_math.h"
#include "mesh.h"
#include "scene.h"
#include "camera.h"

#ifdef analysis
typedef struct {
	float maxx, maxy, minx, miny;
} bbox2_t;

typedef struct {
	vec2_t vec;						//sample vector => offset without pixel coords
	cRGB_t * col;					//color of sample	
	shape_t * shape;				//shape of matching sample
	bbox2_t * bbox;					//bounding box of shap from sample
	//shapes info ndc raster .... barycentric
} sample_t;

typedef struct {
	unsigned int px_x, px_y; 		//pixel
	sample_t * samples;				//samples per pixel
	cRGB_t * pc;					//pixel color => summary of sample colors
} analyse_pixel_t;

typedef struct {
	//here we must add camera and projection parameter
} analyse_t;

#endif

#ifdef debug
	#include "linked_list.h"
#endif

typedef enum {
	RP_PERSPECTIVE, 
	RP_ORTHOGRAPHIC
} projection_t;

typedef struct {
	int imgWidth;
	int imgHeight;
	float imgWidth_half;
	float imgHeight_half;
	int bufWidth;
	int bufHeight;
	camera_t camera;
	unsigned int samplestep;
	unsigned int used_samples;
	vec2_t * samples;
	float sample_factor;
	cRGB_t * frameBuffer;
	float * zBuffer;
	cRGB_t * texture; //TODO here we need a list of textures...currently we use one as test
	cRGB_t bgcolor;
	projection_t projection;
	float min_z;
	float max_z;
	#ifdef analysis
		
	#endif
	#ifdef debug
		linkedlist * debug_head;
		linkedlist ** debug_output;
	#endif
} renderer_t;

#ifdef debug
	void add_debug_output(renderer_t * renderer, unsigned int curindex,const char * msg, ...);
	void add_debug_head(renderer_t * renderer, const char * msg, ...);
#endif

#if 0
	/**
		-render function 
			- worldToCam projection
			- world => NDC conversion
			- NDC => raster conversion
	 
		should add missing vertice or object or something same to parameterlist. Not know yet. prototype data will be set inside.
	 */
#endif
void render_scene(renderer_t * renderer, const scene_t * scene);
void render_mesh(renderer_t * renderer, const mesh_t * mesh);
void render_shape(renderer_t * renderer, const shape_t * shape);

#ifdef analysis
void a_render_scene(renderer_t * renderer, const scene_t * scene, unsigned int px, unsigned int py, analyse_t * analyse);
void a_render_mesh(renderer_t * renderer, const mesh_t * mesh, unsigned int px, unsigned int py, analyse_t * analyse);
void a_render_shape(renderer_t * renderer, const shape_t * shape, unsigned int px, unsigned int py, analyse_t * analyse);
#endif

void renderer_clear_frame(renderer_t * renderer);

#if 0
	/**
		Create renderer
	*/
#endif
renderer_t * renderer_new(int imgWidth, int imgHeight, cRGB_t * bgColor, unsigned int samplestep);

#if 0
	/**
		Deletes renderer
	*/
#endif
void renderer_free(renderer_t * renderer);

#if 0
	/**
		saves renderer output
	*/
#endif
void renderer_output_ppm(renderer_t * renderer, const char * filename);
#if 0
	/**
		saves z buffer output
	*/
#endif
void renderer_output_z_buffer_ppm(renderer_t * renderer, const char * filename);

#endif