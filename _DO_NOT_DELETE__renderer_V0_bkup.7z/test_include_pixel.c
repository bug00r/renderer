void test_pixel() {
	#ifdef debug
		printf(">> test pixel\n");
	#endif	
	
	#ifdef debug
		printf("<< test pixel\n");
	#endif
}