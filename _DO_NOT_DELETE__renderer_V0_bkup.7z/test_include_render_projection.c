void test_render_projection() {
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 0.f, 0.f, 2.0f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer(
									32 /*width*/, 32/*height*/,
									&from, &to, 
									1.0f /* zoom */,
									-1.f /* left */, 1.f /*right*/, 
									1.f /* top */, -1.f /*bottom*/, 
									1.f /* near */, 100.f /*far*/,
									&bgcolor, 1);
	
	#ifdef debug
		printf("from:\t"); vec3_print(&from);
		printf("to:\t"); vec3_print(&to);
		print_camera(&renderer->camera);
	#endif	
	
	vec3_t p1 = { 0.f, 0.f, 0.f };
	shape_t * shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif

	p1 = (vec3_t){ -0.5f, -0.5f, 0.5f };
	shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif
	
	p1 = (vec3_t){ -0.5f, -0.5f, -0.5f };
	shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif
	
	p1 = (vec3_t){ -0.5f, -0.5f, -20.f };
	shape = create_shape_point3(&p1);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	#ifdef debug
		printf("#########\n");
	#endif
	
	p1 = (vec3_t){ -0.5f, -0.5f, 0.5f };
	vec3_t p2 = { 0.5f, 0.5f, -5.f };
	shape = create_shape_line3(&p1, &p2);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	p1 = (vec3_t){ -0.5f, -0.5f, 0.5f };
	p2 = (vec3_t){ 0.5f, -0.5f, 0.5f };
	vec3_t p3 = {-0.5f, 0.5f, 0.5f};
	shape = create_shape_triangle3(&p1, &p2, &p3);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);

	vec3_t p4 = {0.5f, 0.5f, 0.5f};
	shape = create_shape_triangle3(&p3, &p2, &p4);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	p1.z = -.5f;
	p2.z = -.5f;
	p3.z = -.5f;
	p4.z = -.5f;
	
	shape = create_shape_triangle3(&p2, &p1, &p4);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	shape = create_shape_triangle3(&p4, &p1, &p3);
	test_projection_shape(renderer, shape, NULL, 0);
	free_shape(shape);
	
	renderer_free(renderer);
}
