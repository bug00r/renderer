const camera_t * cam = &renderer->camera;
const mat4_t * transformation = &cam->transformation;
vertex_t ** vertices = shape->vertices;
vertex_t * vertex;
cRGB_t * frameBuffer = renderer->frameBuffer;
cRGB_t * vcolors[3];
barycentric_t bc;
vec3_t pNDC[3],
	   * ndc,
	   pRaster[3],
	   * raster,
	   pixelSample;
const vec2_t * samples = renderer->samples;
const int texId = shape->texId,
	      bufWidth = renderer->bufWidth;
unsigned int curW, 
			 curH;
const unsigned imgW = renderer->imgWidth, 
			   imgH = renderer->imgHeight,
			   used_samples = renderer->used_samples;
float maxx, 
	  maxy, 
	  minx, 
	  miny,
	  over_z,
	  z,
	  * old_z,
	  weight[3],
	  * fweight,
	  z0,z1,z2,z3,
	  * zBuffer = renderer->zBuffer;
const float imgW_h = renderer->imgWidth_half,
			imgH_h = renderer->imgHeight_half,
			sample_factor = renderer->sample_factor;
bool is_triangle, 
	 is_line, 
	 is_point,
	 isVisible,
	 completeout;//this is only a test. here we should implement complete fine frustum culling