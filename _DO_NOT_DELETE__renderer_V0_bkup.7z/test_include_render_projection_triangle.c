void
test_render_projection_triangle() {
	#ifdef debug
		printf(">> Projection Triangle\n");
	#endif
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 0.f, 0.f, 2.0f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer(
									512 /*width*/, 512/*height*/,
									&from, &to, 
									0.5f /* zoom */,
									-2.f /* left */, 2.f /*right*/, 
									2.f /* top */, -2.f /*bottom*/, 
									1.f /* near */, 100.f /*far*/,
									&bgcolor, 1);
	
	vec3_t p1 = { -0.75f, -0.75f, 0.75f };
	vec3_t p2 = { 0.75f, -0.55f, 0.25f };
	vec3_t p3 = { 0.05f, 0.75f, -0.75f };
	
	shape_t * triangle = create_shape_triangle3(&p1, &p2, &p3);			

	
	vec2_t triggerpixel[2] = {
		(vec2_t) {66.f, 445.f },
		(vec2_t) {268.f, 70.f }
	};
	
	test_projection_shape(renderer, triangle, triggerpixel, 2);

	#ifdef debug
		printf("min_z:\t%f\n", renderer->min_z);
		printf("max_z:\t%f\n", renderer->max_z);
	#endif
	
	free_shape(triangle);
	#ifdef debug
		printf("<< Projection Triangle\n");
	#endif
}
