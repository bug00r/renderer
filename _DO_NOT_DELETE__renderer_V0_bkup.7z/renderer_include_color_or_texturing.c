cRGB_t curCol1;

if (is_triangle) {
	#if 0
		//https://www.gamedev.net/forums/topic/593669-perspective-correct-barycentric-coordinates/
	#endif
	z0 = bc.bc0*weight[0];
	z1 = bc.bc1*weight[1];
	z2 = bc.bc2*weight[2];
	z3 = 1.f/(z0 + z1 + z2);
	
	if (texId == -1) {
		curCol1.r = (z0*vcolors[0]->r + z1*vcolors[1]->r + z2*vcolors[2]->r ) * z3;
		curCol1.g = (z0*vcolors[0]->g + z1*vcolors[1]->g + z2*vcolors[2]->g ) * z3;
		curCol1.b = (z0*vcolors[0]->b + z1*vcolors[1]->b + z2*vcolors[2]->b ) * z3;
	} else {							
		#include "renderer_include_texture.c"
	}
} else if (is_line) {
	crgb_crgb_copy(&curCol1, vcolors[0]);
} else if (is_point) {
	crgb_crgb_copy(&curCol1, vcolors[0]);
}

crgb_mul(&curCol1, sample_factor);
crgb_crgb_copy(&frameBuffer[bi], &curCol1);
