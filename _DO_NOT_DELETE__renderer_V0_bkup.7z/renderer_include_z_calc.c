if (is_triangle) {
	over_z = pRaster[0].z * bc.bc0 +  
			 pRaster[1].z * bc.bc1 + 
			 pRaster[2].z * bc.bc2;
} else if (is_line) {
	over_z = pRaster[0].z * (1.f - bc.bc2) +  pRaster[1].z * bc.bc2;
} else if (is_point) {
	over_z = pRaster[0].z;
}

z = 1.f / over_z;