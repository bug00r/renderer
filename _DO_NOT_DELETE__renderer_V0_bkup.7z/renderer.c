#include <stdlib.h>
#include <stdio.h>
#include "renderer.h"

#ifdef debug
	void add_debug_output(renderer_t * renderer, unsigned int curindex,const char * msg, ...){
		va_list vl;
		va_start(vl, msg);
		int buffsize = vsnprintf(NULL, 0, msg, vl);
		va_end(vl);
		buffsize += 1;
		char * buffer = malloc(buffsize);
		va_start(vl, msg);
		vsnprintf(buffer, buffsize, msg, vl);
		va_end( vl);
		linkedlistutils.append(renderer->debug_output[curindex], buffer);
	}
	
	void add_debug_head(renderer_t * renderer, const char * msg, ...){
		va_list vl;
		va_start(vl, msg);
		int buffsize = vsnprintf(NULL, 0, msg, vl);
		va_end(vl);
		buffsize += 1;
		char * buffer = malloc(buffsize);
		va_start(vl, msg);
		vsnprintf(buffer, buffsize, msg, vl);
		va_end( vl);
		linkedlistutils.append(renderer->debug_head, buffer);
	}
#endif

void render_shape(renderer_t * renderer, const shape_t * shape){
	#include "renderer_include_variables.c"
	#include "renderer_include_world_to_raster.c"
	#include "renderer_include_bounding_box.c"
	
	for(; curH < maxy; ++curH) {
		for(curW = minx; curW < maxx; ++curW) {
			for (unsigned int sample = renderer->used_samples; sample--;) {
				vec2_t * cursample = &renderer->samples[sample];
				pixelSample.x = curW + cursample->x;
				pixelSample.y = curH + cursample->y;
				
				#include "renderer_include_single_pixel.c"
			}
		}
	}
}

void render_mesh(renderer_t * renderer, const mesh_t * mesh){
	for(unsigned int cntShape = mesh->cntShapes; cntShape-- ;) {
		render_shape(renderer, mesh->shapes[cntShape]);
	} 
}

void 
render_scene(renderer_t * renderer, const scene_t * scene){	
	for(int cntMesh = scene->cntMesh; cntMesh--; ) {
		render_mesh(renderer, scene->meshes[cntMesh]);
	}
}

#ifdef analysis

void a_render_shape(renderer_t * renderer, const shape_t * shape, unsigned int px, unsigned int py, analyse_t * analyse){
	#include "renderer_include_variables.c"
	#include "renderer_include_world_to_raster.c"
	#include "renderer_include_bounding_box.c"
	
	for(; curH < maxy; ++curH) {
		for(curW = minx; curW < maxx; ++curW) {
			for (unsigned int sample = used_samples; sample--;) {
				vec2_t * cursample = &samples[sample];
				pixelSample.x = curW + cursample->x;
				pixelSample.y = curH + cursample->y;
				
				#include "renderer_include_single_pixel.c"
			}
		}
	}
}

void a_render_mesh(renderer_t * renderer, const mesh_t * mesh, unsigned int px, unsigned int py, analyse_t * analyse){
	for(unsigned int cntShape = mesh->cntShapes; cntShape-- ;) {
		a_render_shape(renderer, mesh->shapes[cntShape]);
	} 
}

void 
a_render_scene(renderer_t * renderer, const scene_t * scene, unsigned int px, unsigned int py, analyse_t * analyse){	
	for(int cntMesh = scene->cntMesh; cntMesh--; ) {
		a_render_mesh(renderer, scene->meshes[cntMesh]);
	}
}

#endif

void renderer_clear_frame(renderer_t * renderer){
	const int buffersize = renderer->imgWidth * 
					 renderer->imgHeight * 
					 renderer->samplestep * renderer->samplestep;
	cRGB_t *bgcolor = &renderer->bgcolor;
	cRGB_t * fb = renderer->frameBuffer;
	float * zb = renderer->zBuffer;
	for(unsigned int i = buffersize; i--;){
		crgb_crgb_copy(&fb[i], bgcolor);
		zb[i] = FLT_MAX;
	}

	renderer->min_z = FLT_MAX;
	renderer->max_z = 0.f;
}

renderer_t * 
renderer_new(int imgWidth, int imgHeight, cRGB_t * bgColor, unsigned int samplestep){
	renderer_t * newrenderer = malloc(sizeof(renderer_t));
	newrenderer->projection = RP_ORTHOGRAPHIC;
	newrenderer->texture = NULL;
	newrenderer->imgWidth = imgWidth;
	newrenderer->imgHeight = imgHeight;
	newrenderer->imgWidth_half = 0.5f * imgWidth;
	newrenderer->imgHeight_half = 0.5f * imgHeight;
	newrenderer->bufWidth = imgWidth * samplestep * samplestep;
	newrenderer->bufHeight = imgHeight;
	newrenderer->samplestep = samplestep;
	unsigned int buffersize = imgWidth * imgHeight * samplestep * samplestep;
	newrenderer->frameBuffer = malloc(buffersize * sizeof(cRGB_t));
	newrenderer->zBuffer = malloc(buffersize * sizeof(float));
	crgb_crgb_copy(&newrenderer->bgcolor, bgColor);
	renderer_clear_frame(newrenderer);
	newrenderer->min_z = FLT_MAX;
	newrenderer->max_z = 0.f;
	#if 0
		//add samples logic
	#endif
	newrenderer->used_samples = samplestep*samplestep;
	newrenderer->sample_factor = 1.f/newrenderer->used_samples;
	float stepstart = 0.5f / (float)samplestep; //for st = 2 step is .25  for st = 4 0.125
	float step = 2.f*stepstart; //distance between 

	newrenderer->samples = malloc(newrenderer->used_samples * sizeof(vec2_t));

	for( unsigned int sy = 0; sy < samplestep ;++sy ){
		for( unsigned int sx = 0; sx < samplestep ;++sx ){
			vec2_t  *cursample = &newrenderer->samples[sy * samplestep + sx];
			cursample->x = stepstart + (sx * step);
			cursample->y = stepstart + (sy * step);
		}
	}
	
	#ifdef debug
		printf("samples with steP => %u\n", newrenderer->samplestep);
	#endif
	
	#ifdef debug
		newrenderer->debug_head = linkedlistutils.new();
		newrenderer->debug_output = malloc(buffersize * sizeof(linkedlist*));
		for(unsigned int i = 0; i < buffersize; ++i){
			newrenderer->debug_output[i] = linkedlistutils.new();
		}
	#endif
	return newrenderer;
}

void 
renderer_free(renderer_t * renderer){
	free(renderer->frameBuffer);
	free(renderer->zBuffer);
	if (renderer->texture != NULL) {
		free(renderer->texture);
	}
	#ifdef debug	
		linkedlistutils.delete(renderer->debug_head, free);
		unsigned int buffersize = renderer->imgWidth*renderer->imgHeight;
		for(unsigned int i = 0; i < buffersize; ++i){
			linkedlistutils.delete(renderer->debug_output[i], free);
		}
		free(renderer->debug_output);
	#endif
	free(renderer);
}


void 
renderer_output_ppm(renderer_t * renderer, const char * filename){
	unsigned int colcnt=0, bi=0, samplestart;
	int i, j, imgW = renderer->imgWidth, imgH = renderer->imgHeight;
    FILE *fp = fopen(filename, "wb"); /* b - binary mode */
    (void) fprintf(fp, "P6\n%d %d\n255\n", imgW, imgH);
	cRGB_t fc;
	unsigned char color[3*imgW*imgH];
    for (j = 0; j < imgH; ++j){
	  bi = j * renderer->bufWidth;
	  for (i = 0; i < imgW; ++i){
		fc.r = 0.f, fc.g = 0.f, fc.b = 0.f;
		samplestart = bi + (i*renderer->used_samples);
		for (unsigned int sample = renderer->used_samples; sample--;){
			cRGB_t * c = &renderer->frameBuffer[samplestart + sample];
			crgb_crgb_add(&fc, c);
		}
	 
		color[colcnt++] = (unsigned char)(fc.r * 255.f);
		color[colcnt++] = (unsigned char)(fc.g * 255.f);
		color[colcnt++] = (unsigned char)(fc.b * 255.f);
	  }
    }
	(void) fwrite(color, 1, 3*imgW*imgH, fp);
    (void) fclose(fp);
}

void 
renderer_output_z_buffer_ppm(renderer_t * renderer, const char * filename){
	unsigned int colcnt=0,bi=0,samplestart;
	int i, j, imgW = renderer->imgWidth, imgH = renderer->imgHeight;
    FILE *fp = fopen(filename, "wb"); /* b - binary mode */
    (void) fprintf(fp, "P6\n%d %d\n255\n", imgW, imgH);
	float _color, samplefactor = renderer->sample_factor;
	unsigned char color[3*imgW*imgH];
	
    for (j = 0; j < imgH; ++j){
	  bi = j * renderer->bufWidth;
	  for (i = 0; i < imgW; ++i){
		_color = 0.f;
		samplestart = bi + (i*renderer->used_samples);
		for (unsigned int sample = renderer->used_samples; sample--;){
			_color += renderer->zBuffer[samplestart + sample];
		}
		
		_color *= samplefactor ;
		
		if ( _color != FLT_MAX ){
			_color = (unsigned char)interpolate_lin(_color, renderer->max_z, 0.f, renderer->min_z, 255.f);
		} else {
			_color = 0.f;
		}
				
		color[colcnt++] = _color;
		color[colcnt++] = _color;
		color[colcnt++] = _color;
	  }
    }
	(void) fwrite(color, 1, 3*imgW*imgH, fp);
    (void) fclose(fp);
}
