void
test_render_projection_square_block() {
	#ifdef debug
		printf(">> Projection square block\n");
	#endif
	cRGB_t  bgcolor = {0.0f, 0.0f, 0.0f};
	vec3_t from = { 0.f, 0.f, 2.0f };
	vec3_t to = { 0.0f, 0.0f, 0.0f };
	renderer_t *renderer = create_renderer(
									512 /*width*/, 512/*height*/,
									&from, &to, 
									1.0f /* zoom */,
									-2.f /* left */, 2.f /*right*/, 
									2.f /* top */, -2.f /*bottom*/, 
									1.f /* near */, 100.f /*far*/,
									&bgcolor,1);
	
	vec3_t center = { 0.f, 0.f, 0.f };
	mesh_t * square_block = create_square_block(&center, 1.f, 1.f, 1.f, 1, 1, 1);			

	mat3_t * rotz_mat = create_rot_z_mat(0.f);
	mat3_t * rotx_mat = create_rot_x_mat(20.f);
	mat3_t * roty_mat = create_rot_y_mat(20.f);
	mat3_mul(rotz_mat, rotx_mat);
	mat3_mul(rotz_mat, roty_mat);
	mat_mul_mesh(square_block, rotz_mat);
	
	free(rotz_mat);
	free(rotx_mat);
	free(roty_mat);	
	
	
	vec2_t triggerpixel[2] = {
		(vec2_t) {138.f, 81.f },
		(vec2_t) {274.f, 200.f }
	};
	
	for(unsigned int curShape = 0; curShape < square_block->cntShapes; ++curShape) {
		shape_t * shape = square_block->shapes[curShape];
		test_projection_shape(renderer, shape, triggerpixel, 2);
	}
	
	#ifdef debug
		printf("min_z:\t%f\n", renderer->min_z);
		printf("max_z:\t%f\n", renderer->max_z);
	#endif
	
	free_mesh(square_block);
	#ifdef debug
		printf("<< Projection square block\n");
	#endif
}
