
#include "renderer_include_visibility.c"

#ifdef debug
	add_debug_output(renderer, curH * renderer->imgWidth + curW, "cur(x|y):\t %i %i", curW, curH);
	add_debug_output(renderer, curH * renderer->imgWidth + curW,
			"bc(0 1 2):\t %f %f %f values (%f %f %f)", bc.bc0, bc.bc1, bc.bc2, bc.w0_12, bc.w1_20, bc.w2_01);
	add_debug_output(renderer, curH * renderer->imgWidth + curW, "bc.inside: %i", bc.inside);
#endif

if(isVisible) {

	#include "renderer_include_z_calc.c"
	
	unsigned int bi = curH * bufWidth + (curW * used_samples) + sample;
	
	old_z = &zBuffer[bi];

	#ifdef debug
		add_debug_output(renderer, bi, "old-z:\t\t %f", *old_z);
		add_debug_output(renderer, bi, "new-z:\t\t %f", z);
	#endif

	if ( z < *old_z ) {
		*old_z = z;
		#ifdef debug
			add_debug_output(renderer, bi, "z-changed!!",1);
		#endif
		
		renderer->min_z = fminf(renderer->min_z, z);
		renderer->max_z = fmaxf(renderer->max_z, z);
		
		#include "renderer_include_color_or_texturing.c"
	}
}
