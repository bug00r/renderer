void test_projection_shape(renderer_t *renderer, shape_t * shape, vec2_t * trigger_pixel, unsigned int cnttrigger ) {
	#ifdef debug
		printf("################################################\n");
		printf("################# SHAPE ########################\n");
		printf("################################################\n");
	#endif
	#include "renderer_include_variables.c"
	#include "renderer_include_world_to_raster.c"
	
	#ifdef debug
	for(unsigned int curVertex = 0; curVertex < shape->cntVertex ; ++curVertex) {
		vertex_t * vertex = shape->vertices[curVertex];
	
		printf("[%i]world:\t", curVertex); vec3_print(&vertex->vec);
		printf("[%i]ndc:\t\t", curVertex); vec3_print(&pNDC[curVertex]);
		printf("[%i]raster:\t", curVertex); vec3_print(&pRaster[curVertex]);		
		printf("[%i]color:\t", curVertex); crgb_print(&vertex->color);
	}
	#endif
	#include "renderer_include_bounding_box.c"
	
	#ifdef debug
		printf("samples:\t%f\n", renderer->samplestep);
		printf("b-box:\t\tminx: %f miny: %f maxx: %f maxy: %f\n", minx, miny, maxx, maxy);
	#endif

	if ( trigger_pixel != NULL ) {
		#ifdef debug
		printf("]]]- ----  Fire Pixel against shape:\n");
		#endif
		for ( unsigned int curpx = 0; curpx < cnttrigger; ++curpx) {
			#ifdef debug
				printf("####### Pixel ##########\n");
			#endif
			vec2_t triggerpx = trigger_pixel[curpx];
			curW = triggerpx.x;
			curH = triggerpx.y;
			unsigned int sample=0;
			#include "renderer_include_single_pixel.c"
			#ifdef debug
				printf("curPx:\t\t"); vec3_print(&pixelSample);
				printf("visible:\t%i\n", isVisible);
				printf("barycentric:\n");
				print_barycentric(&bc);
				printf("z, over_z:\t%f, %f\n", z, over_z);
				cRGB_t * color = &renderer->frameBuffer[curH * renderer->imgWidth + curW];
				printf("color:\t %f %f %f\n", color->r, color->g, color->b);
			#endif

		}
	}
}
