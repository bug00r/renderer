
isVisible = false;
if (is_triangle || is_line) {
	if (is_triangle) {
		is_inside_triangle( &pRaster[0], &pRaster[1], &pRaster[2], &pixelSample, &bc);
	} else {
		bc.inside = false;
		bc.bc2 = (pixelSample.x - pRaster[0].x ) / (pRaster[1].x - pRaster[0].x);
		float edge = place_of_vec3(&pRaster[0], &pRaster[1], &pixelSample);
		vec3_t *limitvec = vec3_sub_new(&pRaster[1], &pRaster[0]);
		float limit = vec3_length(limitvec) *0.5f;
		if ( ( (edge <= limit && edge >= 0.f) || (edge >= -limit && edge <= 0.f) ) ) {		 
			bc.inside = true;
		}
		free(limitvec);
	}
	isVisible = bc.inside;
} else if (is_point) {
	
	isVisible = (pRaster[0].x >= 0) &&
				 (pRaster[0].x <= imgW) &&
				 (pRaster[0].y >= 0) &&
				 (pRaster[0].y <= imgH);
	if(isVisible) {
		curW = pRaster[0].x;
		curH = pRaster[0].y;
	}
}
